<!--
.. title: AskOmics 3.2.3
.. slug: askomics-323
.. date: 2020-01-21
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.3](https://github.com/askomics/flaskomics/releases/tag/3.2.3) is out!

Bug fixes and minor improvements

- fix delete dataset
- Malformed input display an error message
- Keep col order when using with isqlapi
- Fix save query without selected node

