<!--
.. title: AskOmics 3.2.5
.. slug: askomics-325
.. date: 2020-01-30
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.5](https://github.com/askomics/flaskomics/releases/tag/3.2.5) is out!

Bug fixes and minor improvements
