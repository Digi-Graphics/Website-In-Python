<!--
.. title: AskOmics 3.2.7
.. slug: askomics-327
.. date: 2020-02-18
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.7](https://github.com/askomics/flaskomics/releases/tag/3.2.7) is out!

Bug fixes and minor improvements
