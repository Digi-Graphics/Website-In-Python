<!--
.. title: AskOmics 3.2.8
.. slug: askomics-328
.. date: 2020-03-02
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.8](https://github.com/askomics/flaskomics/releases/tag/3.2.8) is out!

Bug fixes and minor improvements
