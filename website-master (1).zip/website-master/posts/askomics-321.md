<!--
.. title: AskOmics 3.2.1
.. slug: askomics-321
.. date: 2020-01-06 14:08:34 UTC+02:00
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.1](https://github.com/askomics/flaskomics/releases/tag/3.2.1) is out!



- Redo chunk integration if failure
- Redo graph deletion if failure
- Select base at startpoints
- Edit CSV headers
- Template and public queries
- Bugfixes and minor improvments

