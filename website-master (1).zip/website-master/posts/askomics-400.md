<!--
.. title: AskOmics 4.0.0
.. slug: askomics-400
.. date: 2020-09-14 16:34:29 UTC+02:00
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 4.0.0](https://github.com/askomics/flaskomics/releases/tag/4.0.0) is out!

**Major release**

Partially compatible with AskOmics 3.x.x. User accounts and uploaded files can be kept, but all RDF data and saved queries must be deleted befor upgrading.

### Major features

- Union query
- Several numerci attribute
- ldap auth
- Admin can create users
- Admin can delete user and user can delete themselve
- don't show public datasets to guests
- Boolean value
- Password recovery
- Change default namespace

### Minor features

- Makefile for install build run test ...
- Store abstraction in sql database
- Welcome message
- Human id in results file
- Start query with the sparql editor
- Check for endpoint metadata during RDF integration
- Integrate al RDF format

