<!--
.. title: AskOmics 3.2.2
.. slug: askomics-322
.. date: 2020-01-16 14:08:34 UTC+02:00
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.2](https://github.com/askomics/flaskomics/releases/tag/3.2.2) is out!

- Use isql-api 2.1.0
- Use isql-api for all select and load queries
- Integration: display percent
- CSV: detect link when column editing
- Display query exec time
- Bug fixes and minor imrpovments


