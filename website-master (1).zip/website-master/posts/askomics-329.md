<!--
.. title: AskOmics 3.2.9
.. slug: askomics-329
.. date: 2020-03-04
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.9](https://github.com/askomics/flaskomics/releases/tag/3.2.9) is out!

Bug fixes and minor improvements
