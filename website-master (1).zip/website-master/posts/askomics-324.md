<!--
.. title: AskOmics 3.2.4
.. slug: askomics-324
.. date: 2020-01-22
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.4](https://github.com/askomics/flaskomics/releases/tag/3.2.4) is out!

Bug fixes and minor improvements
