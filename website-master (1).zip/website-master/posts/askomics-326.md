<!--
.. title: AskOmics 3.2.6
.. slug: askomics-326
.. date: 2020-01-31
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.6](https://github.com/askomics/flaskomics/releases/tag/3.2.6) is out!

Bug fixes and minor improvements
