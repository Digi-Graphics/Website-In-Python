<!--
.. title: AskOmics 3.2.0
.. slug: askomics-320
.. date: 2019-11-20 14:08:34 UTC+02:00
.. tags: new release
.. category: 
.. link: 
.. description: 
.. type: text
-->

## [AskOmics 3.2.0](https://github.com/askomics/flaskomics/releases/tag/3.2.0) is out!

- Support federated queries
- Docker size reduced
