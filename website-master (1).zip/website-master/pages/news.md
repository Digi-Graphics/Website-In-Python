<!--
.. title: News
.. slug: news
.. date: 2022-02-25 12:51:18 UTC+02:00
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

## Releases

All current available AskOmics releases are available [here](https://github.com/askomics/flaskomics/releases)

## Changelog

A detailed changelog (starting from release 4.2.0) is available [here](https://github.com/askomics/flaskomics/blob/dev/CHANGELOG.md)
