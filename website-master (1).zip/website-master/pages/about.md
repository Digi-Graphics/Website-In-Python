<!--
.. title: About
.. slug: about
.. date: 2020-05-04 21:22:14 UTC+02:00
.. tags: 
.. category: 
.. link: 
.. description: 
.. type: text
-->

AskOmics is a visual SPARQL query interface supporting both intuitive data integration and querying while shielding the user from most of the technical difficulties underlying RDF and SPARQL.